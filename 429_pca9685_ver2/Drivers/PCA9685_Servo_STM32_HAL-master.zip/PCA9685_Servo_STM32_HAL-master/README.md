STM32 HAL library for PCA9685 PWM LED and Servo driver.

This project uses STM32CubeMX and SW4STM32 IDE with STM32L053R8 Nucleo.

https://msalamon.pl/jak-pomachac-swoim-orczykiem-stm32-spotyka-sie-z-serwem/